public class Overloading {
    public static void main(String[] args) {
        toplama(12, 23);
        toplama(12, 23, 25);
        toplama("Cihan", "Yusuf");
    }
    public static void toplama(int a, int b) {
        System.out.println("Birinci sayı:" + a + "  İkinci sayı:" + b + "  Toplam=" + (a + b));
    }
    /*   (Örnek olarak gösterilen yanlış kısım)
    public static void toplama(int a, int b) {
        System.out.println("Birinci sayı:" + a + "  İkinci sayı:" + b + "  Toplam=" + (a + b));
    } */
    public static void toplama(int a, int b, int c) {
        System.out.println("Birinci sayı:" + a + "  İkinci sayı:" + b + "  Üçüncü sayı:" + c + "  Toplam=" + (a + b + c));
    }
    public static void toplama(String a, String b) {
        System.out.println("Birici kelime:" + a + "  İkinci kelime:" + b);
    }
}