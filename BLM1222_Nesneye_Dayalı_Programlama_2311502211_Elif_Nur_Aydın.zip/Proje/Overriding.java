public class Overriding {
    public static void main(String[] args) {
        dog hayvanTuru = new dog();
        System.out.println(hayvanTuru.hareket());
        System.out.println(hayvanTuru.yemek());
    }
}
class Animal {
    public String hareket() {
        return "Hareket ederim";
    }
    public String yemek() {
        return "Yemek yerim";
    }
}
class dog extends Animal {

    public String hareket() {
        return "Koşarım";
    }
}